
open source resume(html+js+css)

<h2>开源简历（open source resume）</h2>
自己应聘做了一个简历,喜欢的可以去改成自己；
code写的也不够标准，有兴趣的可以协助修改下。

一些特色：
<ul>
  <li>响应式布局</li>
  <li>局部打印</li>
  <li>语音操作</li>
</ul>


